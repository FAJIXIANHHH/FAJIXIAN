/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50722
 Source Host           : localhost:3306
 Source Schema         : login

 Target Server Type    : MySQL
 Target Server Version : 50722
 File Encoding         : 65001

 Date: 16/06/2019 21:50:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book_info
-- ----------------------------
DROP TABLE IF EXISTS `book_info`;
CREATE TABLE `book_info`  (
  `book_name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `book_id` int(20) NOT NULL,
  `book_kind` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `book_author` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `book_place` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_date` datetime(6) NULL DEFAULT NULL,
  `book_num` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`book_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
